import greenfoot.*;
import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;
import java.util.*;
/**
 * Write a description of class Text here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Text extends Actor
{    
    public Text(String text)
    {
        setImage(new GreenfootImage (text, 24,Color.WHITE,Color.BLACK));
    }
}
